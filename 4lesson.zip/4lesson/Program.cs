﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace _4lesson
{
    class Program
    {
        /*static void Main(string[] args)
        {
            GetFullName("Roberta ", "May", "Jake");
            GetFullName("Florence ", " Butler", "William");
            GetFullName("Annette ", "Sanchez", "Afton");
        }

        static void GetFullName(string firstName, string lastName, string patronymic)
        {
            Console.WriteLine($"{firstName} {lastName} {patronymic}");
        }
        */
        /*class s 
        {
            static void Main(string[] args)
            {
                Console.OutputEncoding = Encoding.UTF8;                        
                string number = getnumbers();
                List<string> parts = SplitData(number);
                List<int> numbers = TransformData(parts);
                int result = Calculate(numbers);
                DisplayResult(result);
            }
         
            private static string getnumbers()
            {
                Console.Write("Введите числа: ");
                return Console.ReadLine();
            }

            private static List<string> SplitData(string data)
            {
                List<string> parts = new List<string>();
                if (string.IsNullOrWhiteSpace(data))
                {
                    return parts;
                }
                parts.AddRange(data.Split(' '));
                return parts;
            }

            private static List<int> TransformData(List<string> parts)
            {
                List<int> numbers = new List<int>();
                foreach (var part in parts)
                {
                    if (int.TryParse(part, out int number))
                    {
                        numbers.Add(number);
                    }
                }
                return numbers;
            }

            private static int Calculate(List<int> numbers)
            {
                int result = 0;
                foreach (var number in numbers)
                {
                    result += number;
                }
                return result;
            }

            private static void DisplayResult(int result)
            {
                Console.WriteLine("Сумма чисел : " + result);
            }
            */


        /*
        static void Main(string[] args)
        {
            do
            {
                Console.WriteLine("Enter the number of the month: ");
                Console.WriteLine(month(monthnumber(Convert.ToInt32(Console.ReadLine()))));
            }
            while (true);
        }
        enum seasons { nonexisting, Winter, Spring, Summer, Autumn }
        static seasons monthnumber(int n)
        {
            try
            {
                if (n <= 0 || n > 12)
                    throw new Exception("non existing month: enter number from 1 to 12");
                switch ((n % 12) / 3)
                {
                    case 0:
                        return seasons.Winter;
                    case 1:
                        return seasons.Spring;
                    case 2:
                        return seasons.Summer;
                    default: return seasons.Autumn;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return seasons.nonexisting;
            }
        }
        static string month(seasons s)
        {
            switch (s)
            {
                case seasons.Winter:
                    return "winter";
                case seasons.Spring:
                    return "spring";
                case seasons.Summer:
                    return "summer";
                case seasons.Autumn:
                    return "autumn";
                default: return "";
            }
        }
       */
        static void Main(string[] args)
        {
            Console.WriteLine(Fibonachi(20));// любое число
        }
        static int Fibonachi(int n)
        {
            if (n == 0 || n == 1) return n;

            return Fibonachi(n - 1) + Fibonachi(n - 2); 
        }
       
    }
}
